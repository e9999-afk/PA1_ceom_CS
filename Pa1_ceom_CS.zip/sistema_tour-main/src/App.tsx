import { useState } from 'react';
import Header from './components/common/Header';
import HeroSection from './components/home/HeroSection';
import PopularDestinations from './components/home/PopularDestinations';
import WhyChooseUs from './components/home/WhyChooseUs';
import DestinationDetail from './components/destinations/DestinationDetail';
import SearchBar from './components/search/SearchBar';
import SearchFilters from './components/search/SearchFilters';
import DestinationCard from './components/destinations/DestinationCard';
import DestinationMap from './components/destinations/DestinationMap';
import Footer from './components/common/Footer';
import ToursSection from './components/tours/ToursSection';
import ContactSection from './components/contact/ContactSection';
import BookingSummaryDialog from './components/booking/BookingSummaryDialog';
import { NotificationProvider } from './contexts/NotificationContext';
import { BookingProvider } from './contexts/BookingContext';
import { useDestinations } from './hooks/useDestinations';
import { Destination, Booking } from './types';

const AppContent = () => {
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [showAllDestinations, setShowAllDestinations] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [currentSection, setCurrentSection] = useState<string>('inicio');
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);
  
  const destinationsData = useDestinations();

  const handleBookingComplete = (booking: Booking) => {
    setCompletedBooking(booking);
  };

  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'tours':
        return <ToursSection onTourSelect={(tour: Destination) => setSelectedDestination(tour)} />;
      case 'contacto':
        return <ContactSection />;
      default:
        return (
          <>
            <HeroSection />
            <PopularDestinations 
              onDestinationSelect={setSelectedDestination}
              onShowAllDestinations={() => setShowAllDestinations(true)}
            />
            {showAllDestinations && (
              <section className="container mx-auto px-4 py-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-3xl font-bold text-gray-900">Todos los Destinos</h2>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                        viewMode === 'grid'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      Grid
                    </button>
                    <button
                      onClick={() => setViewMode('map')}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                        viewMode === 'map'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      Mapa
                    </button>
                  </div>
                </div>
                <div className="mb-6">
                  <SearchBar 
                    searchTerm={destinationsData.searchTerm}
                    onSearchChange={destinationsData.setSearchTerm}
                  />
                  <SearchFilters 
                    filters={destinationsData.filters}
                    onFiltersChange={destinationsData.setFilters}
                    onClear={destinationsData.clearFilters}
                  />
                </div>
                {viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {destinationsData.destinations.map((destination) => (
                      <DestinationCard
                        key={destination.id}
                        destination={destination}
                        onSelect={() => setSelectedDestination(destination)}
                      />
                    ))}
                  </div>
                ) : (
                  <DestinationMap
                    destinations={destinationsData.destinations}
                    onDestinationSelect={setSelectedDestination}
                  />
                )}
              </section>
            )}
            <WhyChooseUs />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
      />
      
      {renderCurrentSection()}
      
      <Footer />
      
      {selectedDestination && (
        <DestinationDetail
          destination={selectedDestination}
          onClose={() => setSelectedDestination(null)}
          onBookingComplete={handleBookingComplete}
        />
      )}
      
      {completedBooking && (
        <BookingSummaryDialog
          booking={completedBooking}
          onClose={() => setCompletedBooking(null)}
        />
      )}
    </div>
  );
};

function App() {
  return (
    <NotificationProvider>
      <BookingProvider>
        <AppContent />
      </BookingProvider>
    </NotificationProvider>
  );
}

export default App;
