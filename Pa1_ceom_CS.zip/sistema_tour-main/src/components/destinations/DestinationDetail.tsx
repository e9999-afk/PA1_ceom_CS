import React, { useState } from 'react';
import { X, MapPin, Clock, Users, Star, Calendar, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { Destination, Booking } from '../../types';
import BookingForm from '../booking/BookingForm';

interface DestinationDetailProps {
  destination: Destination;
  onClose: () => void;
  onBookingComplete?: (booking: Booking) => void;
}

const DestinationDetail: React.FC<DestinationDetailProps> = ({ destination, onClose, onBookingComplete }) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'itinerary' | 'included'>('overview');

  const nextImage = () => {
    setActiveImageIndex((prev) => 
      prev === destination.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setActiveImageIndex((prev) => 
      prev === 0 ? destination.images.length - 1 : prev - 1
    );
  };

  const handleBookingSuccess = (booking: Booking) => {
    if (onBookingComplete) {
      onBookingComplete(booking);
    }
    onClose();
  };

  if (showBookingForm) {
    return (
      <BookingForm 
        destination={destination} 
        onBack={() => setShowBookingForm(false)}
        onClose={onClose}
        onBookingComplete={handleBookingSuccess}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
          <div className="flex justify-between items-center p-6 border-b border-gray-200">
            <div>
              <h2 className="text-3xl font-bold text-gray-800">{destination.name}</h2>
              <div className="flex items-center space-x-4 mt-2">
                <div className="flex items-center space-x-1">
                  <MapPin size={18} className="text-red-500" />
                  <span className="text-gray-600">{destination.region}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star size={18} className="text-yellow-400 fill-current" />
                  <span className="font-medium">{destination.rating}</span>
                  <span className="text-gray-500">({destination.reviewCount} reseñas)</span>
                </div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-120px)]">

            <div className="relative h-80">
              <img
                src={destination.images[activeImageIndex]}
                alt={destination.name}
                className="w-full h-full object-cover"
              />
              {destination.images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition-all"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition-all"
                  >
                    <ChevronRight size={20} />
                  </button>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                    {destination.images.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setActiveImageIndex(index)}
                        className={`w-2 h-2 rounded-full transition-all ${
                          index === activeImageIndex ? 'bg-white' : 'bg-white/50'
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <Clock size={24} className="text-blue-500 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Duración</p>
                  <p className="font-semibold">{destination.duration}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <Users size={24} className="text-green-500 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Dificultad</p>
                  <p className="font-semibold">{destination.difficulty}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <MapPin size={24} className="text-red-500 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Región</p>
                  <p className="font-semibold">{destination.region}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <Calendar size={24} className="text-red-600 mx-auto mb-2" />
                  <p className="text-sm text-red-600">Precio desde</p>
                  <p className="font-bold text-xl text-red-600">S/ {destination.price.toLocaleString()}</p>
                </div>
              </div>

              <div className="border-b border-gray-200 mb-6">
                <nav className="flex space-x-8">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === 'overview'
                        ? 'border-red-500 text-red-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Descripción
                  </button>
                  <button
                    onClick={() => setActiveTab('itinerary')}
                    className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === 'itinerary'
                        ? 'border-red-500 text-red-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Itinerario
                  </button>
                  <button
                    onClick={() => setActiveTab('included')}
                    className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === 'included'
                        ? 'border-red-500 text-red-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Incluye
                  </button>
                </nav>
              </div>

              <div className="mb-8">
                {activeTab === 'overview' && (
                  <div>
                    <p className="text-gray-700 mb-6 leading-relaxed">{destination.description}</p>
                    <div>
                      <h4 className="text-lg font-semibold mb-3">Puntos Destacados</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {destination.highlights.map((highlight, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Check size={16} className="text-green-500 flex-shrink-0" />
                            <span className="text-gray-700">{highlight}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'itinerary' && (
                  <div className="space-y-6">
                    {destination.itinerary.map((day, index) => (
                      <div key={index} className="border-l-4 border-red-500 pl-6">
                        <h4 className="text-lg font-semibold text-gray-800 mb-2">
                          Día {day.day}: {day.title}
                        </h4>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-medium text-gray-700 mb-1">Actividades:</h5>
                            <ul className="list-disc list-inside text-gray-600 space-y-1">
                              {day.activities.map((activity, actIndex) => (
                                <li key={actIndex}>{activity}</li>
                              ))}
                            </ul>
                          </div>
                          <div className="flex space-x-6">
                            <div>
                              <h5 className="font-medium text-gray-700 mb-1">Comidas:</h5>
                              <p className="text-gray-600">{day.meals.join(', ')}</p>
                            </div>
                            {day.accommodation && (
                              <div>
                                <h5 className="font-medium text-gray-700 mb-1">Alojamiento:</h5>
                                <p className="text-gray-600">{day.accommodation}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'included' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <h4 className="text-lg font-semibold text-green-600 mb-4">✓ Incluye</h4>
                      <ul className="space-y-2">
                        {destination.included.map((item, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <Check size={16} className="text-green-500 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-red-600 mb-4">✗ No Incluye</h4>
                      <ul className="space-y-2">
                        {destination.notIncluded.map((item, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <X size={16} className="text-red-500 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
                  <div>
                    <p className="text-2xl font-bold text-gray-800">
                      S/ {destination.price.toLocaleString()}
                      <span className="text-sm font-normal text-gray-600"> por persona</span>
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      Precios sujetos a disponibilidad
                    </p>
                  </div>
                  <button
                    onClick={() => setShowBookingForm(true)}
                    className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors shadow-lg hover:shadow-xl"
                  >
                    Reservar Ahora
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DestinationDetail;