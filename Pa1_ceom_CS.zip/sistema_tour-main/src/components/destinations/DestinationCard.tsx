import React from 'react';
import { MapPin, Clock, Star } from 'lucide-react';
import { Destination } from '../../types';
import { formatPrice, getDifficultyColor, getCategoryIcon } from '../../utils/helpers';

interface DestinationCardProps {
  destination: Destination;
  onSelect: (destination: Destination) => void;
}

const DestinationCard: React.FC<DestinationCardProps> = ({ destination, onSelect }) => {
  const handleClick = () => {
    onSelect(destination);
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl group"
      onClick={handleClick}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={destination.images[0]}
          alt={destination.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
          <span className="text-sm font-semibold text-gray-800">
            {formatPrice(destination.price)}
          </span>
        </div>
        <div className="absolute top-3 left-3 bg-red-600 text-white rounded-full px-3 py-1 flex items-center space-x-1">
          <span className="text-xs">{getCategoryIcon(destination.category)}</span>
          <span className="text-xs font-medium">{destination.category}</span>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-800 group-hover:text-red-600 transition-colors">
            {destination.name}
          </h3>
          <div className="flex items-center space-x-1">
            <Star size={16} className="text-yellow-400 fill-current" />
            <span className="text-sm text-gray-600">{destination.rating}</span>
            <span className="text-xs text-gray-500">({destination.reviewCount})</span>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {destination.shortDescription}
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin size={16} className="text-red-500" />
            <span>{destination.region}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <Clock size={16} className="text-blue-500" />
            <span>{destination.duration}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(destination.difficulty)}`}>
            {destination.difficulty}
          </div>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors font-medium text-sm">
            Ver Detalles
          </button>
        </div>
      </div>
    </div>
  );
};

export default DestinationCard;