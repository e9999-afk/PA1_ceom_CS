import React from 'react';
import { MapPin } from 'lucide-react';
import { Destination } from '../../types';

interface DestinationMapProps {
  destinations: Destination[];
  onDestinationSelect: (destination: Destination) => void;
}

const DestinationMap: React.FC<DestinationMapProps> = ({ destinations, onDestinationSelect }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Mapa de Destinos</h3>

      <div className="relative bg-gradient-to-br from-green-100 to-blue-100 h-96 rounded-lg overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-200/20 to-blue-200/20"></div>

        <div className="absolute inset-4 border-2 border-green-600/30 rounded-lg"></div>
        
        {destinations.map((destination, index) => {
          const positions: { [key: string]: { top: string; left: string } } = {
            'Cusco': { top: '60%', left: '30%' },
            'Puno': { top: '70%', left: '35%' },
            'Arequipa': { top: '75%', left: '25%' },
            'Ica': { top: '65%', left: '20%' },
            'Loreto': { top: '20%', left: '40%' },
            'Lima': { top: '55%', left: '15%' }
          };

          const position = positions[destination.region] || { top: '50%', left: '50%' };

          return (
            <button
              key={destination.id}
              onClick={() => onDestinationSelect(destination)}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
              style={{ top: position.top, left: position.left }}
            >
              <div className="relative">
                <MapPin 
                  size={32} 
                  className="text-red-600 fill-current drop-shadow-lg group-hover:scale-110 transition-transform" 
                />
                <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  <p className="text-xs font-medium">{destination.name}</p>
                  <p className="text-xs text-gray-500">S/ {destination.price.toLocaleString()}</p>
                </div>
              </div>
            </button>
          );
        })}

        <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2">
            <MapPin size={16} className="text-red-600 fill-current" />
            <span className="text-sm text-gray-700">Destinos Disponibles</span>
          </div>
        </div>
      </div>

      <div className="mt-6 space-y-3">
        <h4 className="font-semibold text-gray-800">Destinos en el Mapa</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {destinations.map((destination) => (
            <button
              key={destination.id}
              onClick={() => onDestinationSelect(destination)}
              className="flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left"
            >
              <div>
                <p className="font-medium text-gray-800">{destination.name}</p>
                <p className="text-sm text-gray-600">{destination.region}</p>
              </div>
              <p className="font-semibold text-red-600">S/ {destination.price.toLocaleString()}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DestinationMap;