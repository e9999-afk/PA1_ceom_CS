import React, { useState } from 'react';
import { Search, MapPin, Calendar, Users } from 'lucide-react';

interface HeroSectionProps {
  onSearch?: (searchData: {
    destination: string;
    date: string;
    travelers: string;
  }) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onSearch }) => {
  const [searchData, setSearchData] = useState({
    destination: '',
    date: '',
    travelers: '1 persona'
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchData);
    } else {
      window.dispatchEvent(new CustomEvent('heroSearch', { detail: searchData }));
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setSearchData(prev => ({ ...prev, [field]: value }));
  };
  return (
    <section className="relative h-screen flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-fixed"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg)'
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      <div className="relative z-10 text-center text-white max-w-4xl px-4">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Descubre el
          <span className="block text-red-400">Perú Mágico</span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 font-light opacity-90 max-w-2xl mx-auto">
          Vive experiencias únicas en la cuna de la civilización inca. 
          Desde Machu Picchu hasta el Amazonas, cada destino te sorprenderá.
        </p>

        <form onSubmit={handleSearch} className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-2xl max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 flex items-center space-x-1">
                <MapPin size={16} />
                <span>Destino</span>
              </label>
              <select 
                value={searchData.destination}
                onChange={(e) => handleInputChange('destination', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-gray-800"
              >
                <option value="">Todos los destinos</option>
                <option value="Machu Picchu">Machu Picchu</option>
                <option value="Lago Titicaca">Lago Titicaca</option>
                <option value="Cañón del Colca">Cañón del Colca</option>
                <option value="Líneas de Nazca">Líneas de Nazca</option>
                <option value="Amazonía">Amazonía</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 flex items-center space-x-1">
                <Calendar size={16} />
                <span>Fecha</span>
              </label>
              <input 
                type="date" 
                value={searchData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-gray-800"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 flex items-center space-x-1">
                <Users size={16} />
                <span>Viajeros</span>
              </label>
              <select 
                value={searchData.travelers}
                onChange={(e) => handleInputChange('travelers', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-gray-800"
              >
                <option value="1 persona">1 persona</option>
                <option value="2 personas">2 personas</option>
                <option value="3-5 personas">3-5 personas</option>
                <option value="6+ personas">6+ personas</option>
              </select>
            </div>
            
            <div className="flex items-end">
              <button 
                type="submit"
                className="w-full bg-red-600 hover:bg-red-700 text-white py-2.5 px-4 rounded-lg font-semibold transition-colors shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
              >
                <Search size={20} />
                <span>Buscar Tours</span>
              </button>
            </div>
          </div>
        </form>
      </div>
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;