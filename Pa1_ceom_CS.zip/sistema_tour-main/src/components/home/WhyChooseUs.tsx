import React from 'react';
import { Shield, Award, Users, Clock } from 'lucide-react';

const WhyChooseUs = () => {
  const features = [
    {
      icon: <Shield size={48} className="text-blue-600" />,
      title: 'Viajes Seguros',
      description: 'Protocolos de seguridad certificados y guías especializados para tu tranquilidad.'
    },
    {
      icon: <Award size={48} className="text-yellow-600" />,
      title: '15 Años de Experiencia',
      description: 'Expertos en turismo peruano con miles de viajeros satisfechos.'
    },
    {
      icon: <Users size={48} className="text-green-600" />,
      title: 'Grupos Pequeños',
      description: 'Experiencias personalizadas con grupos reducidos para mejor atención.'
    },
    {
      icon: <Clock size={48} className="text-purple-600" />,
      title: 'Soporte 24/7',
      description: 'Asistencia completa antes, durante y después de tu viaje.'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            ¿Por Qué Elegir PeruTours?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Somos tu mejor aliado para descubrir las maravillas del Perú de manera segura y memorable
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="mb-4 flex justify-center group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;