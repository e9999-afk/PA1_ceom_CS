import React from 'react';
import { destinations } from '../../data/destinations';
import DestinationCard from '../destinations/DestinationCard';
import { Destination } from '../../types';

interface PopularDestinationsProps {
  onDestinationSelect: (destination: Destination) => void;
  onShowAllDestinations: () => void;
}

const PopularDestinations: React.FC<PopularDestinationsProps> = ({ onDestinationSelect, onShowAllDestinations }) => {
  // Show first 3 destinations as popular
  const popularDestinations = destinations.slice(0, 3);

  return (
    <section className="py-16 bg-gray-50" id="destinos">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Destinos Más Populares
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explora los lugares más increíbles del Perú con nuestros tours especializados
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {popularDestinations.map((destination) => (
            <DestinationCard
              key={destination.id}
              destination={destination}
              onSelect={onDestinationSelect}
            />
          ))}
        </div>

        <div className="text-center mt-12">
          <button 
            onClick={onShowAllDestinations}
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors shadow-lg hover:shadow-xl"
          >
            Ver Todos los Destinos
          </button>
        </div>
      </div>
    </section>
  );
};

export default PopularDestinations;