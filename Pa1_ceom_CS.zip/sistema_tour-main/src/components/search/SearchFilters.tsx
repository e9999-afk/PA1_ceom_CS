import React from 'react';
import { SearchFilters as FilterType } from '../../types';

interface SearchFiltersProps {
  filters: FilterType;
  onFiltersChange: (filters: FilterType) => void;
  onClear: () => void;
  sortBy?: string;
  sortOrder?: string;
  onSortChange?: (sortBy: string, sortOrder: string) => void;
  availableRegions?: string[];
  availableCategories?: string[];
}

const SearchFilters: React.FC<SearchFiltersProps> = ({ 
  filters, 
  onFiltersChange, 
  onClear,
  sortBy = 'name',
  sortOrder = 'asc',
  onSortChange,
  availableRegions,
  availableCategories
}) => {
  const regions = availableRegions ? ['Todas', ...availableRegions] : ['Todas', 'Cusco', 'Puno', 'Arequipa', 'Ica', 'Loreto', 'Lima'];
  const categories = availableCategories ? ['Todas', ...availableCategories] : ['Todas', 'Arqueología', 'Aventura', 'Cultural', 'Naturaleza', 'Gastronómico'];
  const difficulties = ['Todas', 'Fácil', 'Moderado', 'Difícil'];
  const durations = ['Todas', '1 día', '2-3 días', '4+ días'];
  const sortOptions = [
    { value: 'name', label: 'Nombre' },
    { value: 'price', label: 'Precio' },
    { value: 'rating', label: 'Calificación' },
    { value: 'duration', label: 'Duración' }
  ];

  const handleFilterChange = (key: keyof FilterType, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-800">Filtros de Búsqueda</h3>
        <button
          onClick={onClear}
          className="text-red-600 hover:text-red-700 transition-colors text-sm font-medium"
        >
          Limpiar Filtros
        </button>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Región</label>
          <select
            value={filters.region}
            onChange={(e) => handleFilterChange('region', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
          >
            {regions.map((region) => (
              <option key={region} value={region === 'Todas' ? '' : region}>
                {region}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Categoría</label>
          <select
            value={filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
          >
            {categories.map((category) => (
              <option key={category} value={category === 'Todas' ? '' : category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Rango de Precio: S/ {filters.priceRange[0].toLocaleString()} - S/ {filters.priceRange[1].toLocaleString()}
          </label>
          <div className="space-y-3">
            <input
              type="range"
              min="0"
              max="1000"
              step="50"
              value={filters.priceRange[0]}
              onChange={(e) => handleFilterChange('priceRange', [Number(e.target.value), filters.priceRange[1]])}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
            />
            <input
              type="range"
              min="0"
              max="1000"
              step="50"
              value={filters.priceRange[1]}
              onChange={(e) => handleFilterChange('priceRange', [filters.priceRange[0], Number(e.target.value)])}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Dificultad</label>
          <select
            value={filters.difficulty}
            onChange={(e) => handleFilterChange('difficulty', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
          >
            {difficulties.map((difficulty) => (
              <option key={difficulty} value={difficulty === 'Todas' ? '' : difficulty}>
                {difficulty}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Duración</label>
          <select
            value={filters.duration}
            onChange={(e) => handleFilterChange('duration', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
          >
            {durations.map((duration) => (
              <option key={duration} value={duration === 'Todas' ? '' : duration}>
                {duration}
              </option>
            ))}
          </select>
        </div>

        {onSortChange && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Ordenar por</label>
            <div className="space-y-2">
              <select
                value={sortBy}
                onChange={(e) => onSortChange(e.target.value, sortOrder)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => onSortChange(sortBy, 'asc')}
                  className={`flex-1 px-3 py-2 text-sm rounded-lg transition-colors ${
                    sortOrder === 'asc'
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Ascendente
                </button>
                <button
                  type="button"
                  onClick={() => onSortChange(sortBy, 'desc')}
                  className={`flex-1 px-3 py-2 text-sm rounded-lg transition-colors ${
                    sortOrder === 'desc'
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Descendente
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchFilters;