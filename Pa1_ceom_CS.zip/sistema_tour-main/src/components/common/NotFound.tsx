import React from 'react';
import { MapPin, Home, Search } from 'lucide-react';

interface NotFoundProps {
  onGoHome?: () => void;
}

const NotFound: React.FC<NotFoundProps> = ({ onGoHome }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full text-center">
        <div className="relative mb-8">
          <div className="text-9xl font-bold text-gray-200">404</div>
          <MapPin size={64} className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-red-500" />
        </div>
        
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Destino no encontrado
        </h1>
        
        <p className="text-gray-600 mb-8">
          La página que buscas no existe o ha sido movida. 
          ¡Pero no te preocupes! Tenemos muchos destinos increíbles esperándote.
        </p>
        
        <div className="space-y-3">
          <button
            onClick={onGoHome}
            className="w-full bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
          >
            <Home size={20} />
            <span>Volver al Inicio</span>
          </button>
          
          <button
            onClick={onGoHome}
            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
          >
            <Search size={20} />
            <span>Explorar Destinos</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
