import React from 'react';
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">PT</span>
              </div>
              <div>
                <h3 className="text-2xl font-bold">PeruTours</h3>
                <p className="text-gray-400">Descubre el Perú</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Somos una agencia de turismo especializada en mostrar la belleza y riqueza cultural del Perú. 
              Ofrecemos experiencias auténticas y memorables para todos nuestros viajeros.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={24} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Destinos</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Tours</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Ofertas</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Sobre Nosotros</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contacto</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin size={18} className="text-red-500 mt-1 flex-shrink-0" />
                <p className="text-gray-300 text-sm">
                  Av. El Sol 123, Cusco<br />
                  Perú
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-red-500 flex-shrink-0" />
                <p className="text-gray-300 text-sm">+51 984 567 890</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={18} className="text-red-500 flex-shrink-0" />
                <p className="text-gray-300 text-sm">info@perutours.com</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2025 PeruTours. Todos los derechos reservados. | 
            <a href="#" className="hover:text-white transition-colors"> Política de Privacidad</a> | 
            <a href="#" className="hover:text-white transition-colors"> Términos y Condiciones</a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;