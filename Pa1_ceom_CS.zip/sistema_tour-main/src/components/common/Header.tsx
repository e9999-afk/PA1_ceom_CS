import React, { useState } from 'react';
import { Menu, X, MapPin, Phone, Mail } from 'lucide-react';

interface HeaderProps {
  currentSection?: string;
  onSectionChange?: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ currentSection = 'inicio', onSectionChange }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

    const handleNavClick = (section: string) => {
    if (onSectionChange) {
      onSectionChange(section);
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-red-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone size={14} />
              <span>+51 984 567 890</span>
            </div>
            <div className="flex items-center space-x-1">
              <Mail size={14} />
              <span>info@perutours.com</span>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-1">
            <MapPin size={14} />
            <span>Lima, Perú</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">PT</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">PeruTours</h1>
              <p className="text-sm text-gray-600">Descubre el Perú</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button 
              onClick={() => handleNavClick('inicio')}
                            className={`text-sm font-medium transition-colors ${
                currentSection === 'inicio' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Inicio
            </button>
            <button 
              onClick={() => handleNavClick('destinos')}
                            className={`text-sm font-medium transition-colors ${
                currentSection === 'destinos' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Destinos
            </button>
            <button 
              onClick={() => handleNavClick('tours')}
                            className={`text-sm font-medium transition-colors ${
                currentSection === 'tours' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Tours
            </button>
            <button 
              onClick={() => handleNavClick('contacto')}
                            className={`text-sm font-medium transition-colors ${
                currentSection === 'contacto' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Contacto
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => handleNavClick('inicio')}
                                className={`block px-3 py-2 text-base font-medium transition-colors ${
                  currentSection === 'inicio' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Inicio
              </button>
              <button 
                onClick={() => handleNavClick('destinos')}
                className={`text-left transition-colors font-medium ${
                  currentSection === 'destinos' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Destinos
              </button>
              <button 
                onClick={() => handleNavClick('tours')}
                className={`text-left transition-colors font-medium ${
                  currentSection === 'tours' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Tours
              </button>
              <button 
                onClick={() => handleNavClick('contacto')}
                className={`text-left transition-colors font-medium ${
                  currentSection === 'contacto' ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Contacto
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;