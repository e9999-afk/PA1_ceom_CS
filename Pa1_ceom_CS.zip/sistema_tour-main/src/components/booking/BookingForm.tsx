import React, { useState } from 'react';
import { ChevronLeft, Calendar, Users, CreditCard } from 'lucide-react';
import { Destination, Booking } from '../../types';
import { useBooking } from '../../contexts/BookingContext';
import { useNotification } from '../../contexts/NotificationContext';
import PaymentForm from './PaymentForm';

interface BookingFormProps {
  destination: Destination;
  onBack: () => void;
  onClose: () => void;
  onBookingComplete?: (booking: Booking) => void;
}

const BookingForm: React.FC<BookingFormProps> = ({ destination, onBack, onClose, onBookingComplete }) => {
  const { actions } = useBooking();
  const { showSuccess } = useNotification();
  const [step, setStep] = useState<'details' | 'payment'>('details');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    document: '',
    travelDate: '',
    travelers: 1,
  });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.firstName.trim()) newErrors.firstName = 'Nombre es requerido';
    if (!formData.lastName.trim()) newErrors.lastName = 'Apellido es requerido';
    if (!formData.email.trim()) newErrors.email = 'Email es requerido';
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email inválido';
    if (!formData.phone.trim()) newErrors.phone = 'Teléfono es requerido';
    if (!formData.document.trim()) newErrors.document = 'Documento es requerido';
    if (!formData.travelDate) newErrors.travelDate = 'Fecha de viaje es requerida';

    const selectedDate = new Date(formData.travelDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate <= today) {
      newErrors.travelDate = 'La fecha debe ser futura';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setStep('payment');
    }
  };

  const handlePaymentSuccess = (paymentMethod: 'yape' | 'plin' | 'card') => {
    const booking: Booking = {
      id: Date.now().toString(),
      destinationId: destination.id,
      destination,
      userInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        document: formData.document,
      },
      travelDate: formData.travelDate,
      travelers: formData.travelers,
      totalPrice: destination.price * formData.travelers,
      paymentMethod,
      paymentStatus: 'completed',
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };

    actions.addBooking(booking);
    
    if (onBookingComplete) {
      onBookingComplete(booking);
    } else {
      onClose();
    }
    
    showSuccess(
      '¡Reserva confirmada!', 
      'Te enviaremos los detalles por email. ¡Prepárate para una aventura increíble!'
    );
  };

  if (step === 'payment') {
    return (
      <PaymentForm
        destination={destination}
        bookingData={formData}
        onBack={() => setStep('details')}
        onSuccess={handlePaymentSuccess}
        onClose={onClose}
      />
    );
  }

  const totalPrice = destination.price * formData.travelers;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
          <div className="flex items-center p-6 border-b border-gray-200">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors mr-4"
            >
              <ChevronLeft size={24} />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Reservar: {destination.name}</h2>
              <p className="text-gray-600">{destination.region} • {destination.duration}</p>
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
            <div className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Información Personal</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nombre *
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                          errors.firstName ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Tu nombre"
                      />
                      {errors.firstName && (
                        <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Apellido *
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                          errors.lastName ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Tu apellido"
                      />
                      {errors.lastName && (
                        <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                          errors.email ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="tu@email.com"
                      />
                      {errors.email && (
                        <p className="text-red-500 text-xs mt-1">{errors.email}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Teléfono *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                          errors.phone ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="+51 123 456 789"
                      />
                      {errors.phone && (
                        <p className="text-red-500 text-xs mt-1">{errors.phone}</p>
                      )}
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Documento de Identidad *
                      </label>
                      <input
                        type="text"
                        name="document"
                        value={formData.document}
                        onChange={handleInputChange}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                          errors.document ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="DNI o Pasaporte"
                      />
                      {errors.document && (
                        <p className="text-red-500 text-xs mt-1">{errors.document}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Detalles del Viaje</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Fecha de Viaje *
                      </label>
                      <div className="relative">
                        <input
                          type="date"
                          name="travelDate"
                          value={formData.travelDate}
                          onChange={handleInputChange}
                          min={new Date().toISOString().split('T')[0]}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
                            errors.travelDate ? 'border-red-500' : 'border-gray-300'
                          }`}
                        />
                        <Calendar size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                      </div>
                      {errors.travelDate && (
                        <p className="text-red-500 text-xs mt-1">{errors.travelDate}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Número de Viajeros
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          name="travelers"
                          value={formData.travelers}
                          onChange={(e) => setFormData(prev => ({ ...prev, travelers: Math.max(1, Number(e.target.value)) }))}
                          min="1"
                          max="10"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                        />
                        <Users size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-xl">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Resumen de Precio</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Precio por persona:</span>
                      <span className="font-medium">S/ {destination.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Cantidad de viajeros:</span>
                      <span className="font-medium">{formData.travelers}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between">
                      <span className="text-lg font-semibold">Total:</span>
                      <span className="text-xl font-bold text-red-600">
                        S/ {totalPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
                >
                  <CreditCard size={20} />
                  <span>Continuar al Pago</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingForm;