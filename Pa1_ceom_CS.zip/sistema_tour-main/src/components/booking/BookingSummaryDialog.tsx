import React from 'react';
import { X, Calendar, Users, MapPin, CreditCard, Download, Phone, Mail, CheckCircle } from 'lucide-react';
import { Booking } from '../../types';
import { formatPrice, formatDate, getPaymentMethodLabel } from '../../utils/helpers';

interface BookingSummaryDialogProps {
  booking: Booking;
  onClose: () => void;
}

const BookingSummaryDialog: React.FC<BookingSummaryDialogProps> = ({ booking, onClose }) => {
  const handleDownloadVoucher = () => {
    // Simular descarga del voucher
    const element = document.createElement('a');
    const file = new Blob(['Voucher de Reserva - PeruTours'], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `voucher-${booking.id}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Mi reserva en PeruTours',
        text: `¡He reservado un increíble tour a ${booking.destination.name}! 🇵🇪`,
        url: window.location.href,
      });
    } else {
      // Fallback para navegadores que no soportan Web Share API
      navigator.clipboard.writeText(
        `¡He reservado un increíble tour a ${booking.destination.name} con PeruTours! 🇵🇪`
      );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-600 to-green-700 p-6 text-white relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <X size={24} />
            </button>
            <div className="flex items-center space-x-3 mb-4">
              <CheckCircle size={32} className="text-green-200" />
              <div>
                <h2 className="text-2xl font-bold">¡Reserva Confirmada!</h2>
                <p className="text-green-100">Tu aventura peruana está lista</p>
              </div>
            </div>
            <div className="bg-white/20 rounded-lg p-3">
              <p className="text-sm opacity-90">Código de reserva</p>
              <p className="text-xl font-bold">{booking.id}</p>
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
            <div className="p-6 space-y-6">
              {/* Destination Info */}
              <div className="border border-gray-200 rounded-xl p-6">
                <div className="flex items-start space-x-4">
                  <img
                    src={booking.destination.images[0]}
                    alt={booking.destination.name}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">
                      {booking.destination.name}
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <MapPin size={16} className="text-red-500" />
                        <span>{booking.destination.region}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar size={16} className="text-blue-500" />
                        <span>{booking.destination.duration}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Precio base</p>
                    <p className="text-xl font-bold text-red-600">
                      {formatPrice(booking.destination.price)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Booking Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-800">Detalles del Viaje</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Fecha de viaje:</span>
                      <span className="font-medium">{formatDate(booking.travelDate)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Viajeros:</span>
                      <span className="font-medium">{booking.travelers} persona{booking.travelers > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Estado:</span>
                      <span className="px-2 py-1 bg-green-100 text-green-600 rounded-full text-sm font-medium">
                        {booking.status === 'confirmed' ? 'Confirmado' : booking.status}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-800">Información del Viajero</h4>
                  <div className="space-y-3">
                    <div>
                      <p className="text-gray-600">Nombre:</p>
                      <p className="font-medium">{booking.userInfo.firstName} {booking.userInfo.lastName}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Email:</p>
                      <p className="font-medium">{booking.userInfo.email}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Teléfono:</p>
                      <p className="font-medium">{booking.userInfo.phone}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Summary */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h4 className="font-semibold text-gray-800 mb-4">Resumen de Pago</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Precio por persona:</span>
                    <span>{formatPrice(booking.destination.price)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cantidad de viajeros:</span>
                    <span>{booking.travelers}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Método de pago:</span>
                    <span className="flex items-center space-x-1">
                      <CreditCard size={16} />
                      <span>{getPaymentMethodLabel(booking.paymentMethod)}</span>
                    </span>
                  </div>
                  <div className="border-t pt-3 flex justify-between text-lg font-bold">
                    <span>Total pagado:</span>
                    <span className="text-green-600">{formatPrice(booking.totalPrice)}</span>
                  </div>
                </div>
              </div>

              {/* Next Steps */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h4 className="font-semibold text-blue-800 mb-3">Próximos Pasos</h4>
                <ul className="space-y-2 text-blue-700">
                  <li className="flex items-start space-x-2">
                    <CheckCircle size={16} className="text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Recibirás un email de confirmación en los próximos minutos</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle size={16} className="text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Te contactaremos 24-48 horas antes del tour con detalles finales</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle size={16} className="text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Descarga tu voucher y guárdalo en tu dispositivo</span>
                  </li>
                </ul>
              </div>

              {/* Contact Info */}
              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <h4 className="font-semibold text-red-800 mb-3">¿Necesitas ayuda?</h4>
                <div className="space-y-2">
                  <div className="flex items-center space-x-3 text-red-700">
                    <Phone size={16} />
                    <span>+51 984 567 890</span>
                  </div>
                  <div className="flex items-center space-x-3 text-red-700">
                    <Mail size={16} />
                    <span>reservas@perutours.com</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="border-t border-gray-200 p-6">
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleDownloadVoucher}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              >
                <Download size={20} />
                <span>Descargar Voucher</span>
              </button>
              <button
                onClick={handleShare}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 px-6 rounded-lg font-semibold transition-colors"
              >
                Compartir
              </button>
              <button
                onClick={onClose}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingSummaryDialog;
