import React, { useState } from 'react';
import { ChevronLeft, CreditCard, Smartphone, Check } from 'lucide-react';
import { Destination } from '../../types';

interface PaymentFormProps {
  destination: Destination;
  bookingData: any;
  onBack: () => void;
  onSuccess: (paymentMethod: 'yape' | 'plin' | 'card') => void;
  onClose: () => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ 
  destination, 
  bookingData, 
  onBack, 
  onSuccess, 
  onClose 
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'yape' | 'plin' | 'card'>('card');
  const [cardData, setCardData] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: '',
  });
  const [isProcessing, setIsProcessing] = useState(false);

  const totalPrice = destination.price * bookingData.travelers;

  const handleCardInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    let formattedValue = value;
    
    if (name === 'number') {
      // Format card number with spaces
      formattedValue = value.replace(/\s/g, '').replace(/(.{4})/g, '$1 ').trim();
      if (formattedValue.length > 19) formattedValue = formattedValue.substring(0, 19);
    } else if (name === 'expiry') {
      // Format expiry date MM/YY
      formattedValue = value.replace(/\D/g, '').replace(/(\d{2})(\d{2})/, '$1/$2');
      if (formattedValue.length > 5) formattedValue = formattedValue.substring(0, 5);
    } else if (name === 'cvv') {
      // Limit CVV to 3-4 digits
      formattedValue = value.replace(/\D/g, '').substring(0, 4);
    }
    
    setCardData(prev => ({ ...prev, [name]: formattedValue }));
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    onSuccess(paymentMethod);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center p-6 border-b border-gray-200">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors mr-4"
            >
              <ChevronLeft size={24} />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Método de Pago</h2>
              <p className="text-gray-600">Selecciona tu método de pago preferido</p>
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
            <div className="p-6">
              {/* Order Summary */}
              <div className="bg-gray-50 p-6 rounded-xl mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Resumen de la Reserva</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Destino:</span>
                    <span className="font-medium">{destination.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Fecha:</span>
                    <span className="font-medium">{new Date(bookingData.travelDate).toLocaleDateString('es-PE')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Viajeros:</span>
                    <span className="font-medium">{bookingData.travelers}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between">
                    <span className="text-lg font-semibold">Total:</span>
                    <span className="text-xl font-bold text-red-600">
                      S/ {totalPrice.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Método de Pago</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentMethod === 'card'
                        ? 'border-red-500 bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <CreditCard size={32} className={`mx-auto mb-2 ${
                      paymentMethod === 'card' ? 'text-red-600' : 'text-gray-600'
                    }`} />
                    <p className="font-medium">Tarjeta de Crédito</p>
                    <p className="text-xs text-gray-500">Visa, Mastercard</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('yape')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentMethod === 'yape'
                        ? 'border-red-500 bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Smartphone size={32} className={`mx-auto mb-2 ${
                      paymentMethod === 'yape' ? 'text-red-600' : 'text-gray-600'
                    }`} />
                    <p className="font-medium">Yape</p>
                    <p className="text-xs text-gray-500">Pago móvil</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('plin')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentMethod === 'plin'
                        ? 'border-red-500 bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Smartphone size={32} className={`mx-auto mb-2 ${
                      paymentMethod === 'plin' ? 'text-red-600' : 'text-gray-600'
                    }`} />
                    <p className="font-medium">Plin</p>
                    <p className="text-xs text-gray-500">Pago móvil</p>
                  </button>
                </div>
              </div>

              {/* Payment Form */}
              <form onSubmit={handlePayment}>
                {paymentMethod === 'card' && (
                  <div className="space-y-4 mb-6">
                    <h4 className="font-semibold text-gray-800">Datos de la Tarjeta</h4>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Número de Tarjeta
                      </label>
                      <input
                        type="text"
                        name="number"
                        value={cardData.number}
                        onChange={handleCardInputChange}
                        placeholder="1234 5678 9012 3456"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Fecha de Expiración
                        </label>
                        <input
                          type="text"
                          name="expiry"
                          value={cardData.expiry}
                          onChange={handleCardInputChange}
                          placeholder="MM/YY"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          CVV
                        </label>
                        <input
                          type="text"
                          name="cvv"
                          value={cardData.cvv}
                          onChange={handleCardInputChange}
                          placeholder="123"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nombre en la Tarjeta
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={cardData.name}
                        onChange={handleCardInputChange}
                        placeholder="Como aparece en la tarjeta"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                        required
                      />
                    </div>
                  </div>
                )}

                {(paymentMethod === 'yape' || paymentMethod === 'plin') && (
                  <div className="text-center mb-6 p-6 bg-gray-50 rounded-xl">
                    <Smartphone size={48} className="mx-auto mb-3 text-red-600" />
                    <h4 className="font-semibold text-gray-800 mb-2">
                      Pago con {paymentMethod.toUpperCase()}
                    </h4>
                    <p className="text-gray-600 text-sm mb-4">
                      Escanea el código QR desde tu aplicación {paymentMethod.toUpperCase()}
                    </p>
                    <div className="w-32 h-32 bg-gray-200 mx-auto rounded-lg flex items-center justify-center">
                      <p className="text-gray-500 text-xs text-center">Código QR<br />simulado</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Número: +51 984 567 890
                    </p>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white py-3 px-6 rounded-lg font-semibold transition-colors shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
                >
                  {isProcessing ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  ) : (
                    <>
                      <Check size={20} />
                      <span>Confirmar Pago</span>
                    </>
                  )}
                </button>

                <p className="text-xs text-gray-500 text-center mt-4">
                  Tu información está protegida con encriptación SSL de 256 bits
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentForm;