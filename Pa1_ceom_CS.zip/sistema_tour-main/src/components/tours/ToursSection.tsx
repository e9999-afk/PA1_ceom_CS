import React, { useState } from 'react';
import { Calendar, Users, Clock, Star, MapPin, ArrowRight } from 'lucide-react';
import { destinations } from '../../data/destinations';
import { Destination } from '../../types';

interface ToursSectionProps {
  onTourSelect: (destination: Destination) => void;
}

const ToursSection: React.FC<ToursSectionProps> = ({ onTourSelect }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDuration, setSelectedDuration] = useState<string>('all');

  const categories = [
    { id: 'all', name: 'Todos los Tours', icon: '🗺️' },
    { id: 'Arqueología', name: 'Arqueológicos', icon: '🏛️' },
    { id: 'Aventura', name: 'Aventura', icon: '🏔️' },
    { id: 'Cultural', name: 'Culturales', icon: '🎭' },
    { id: 'Naturaleza', name: 'Naturaleza', icon: '🌿' },
  ];

  const durations = [
    { id: 'all', name: 'Cualquier duración' },
    { id: '1', name: '1 día' },
    { id: '2-3', name: '2-3 días' },
    { id: '4+', name: '4+ días' },
  ];

  const filteredTours = destinations.filter(destination => {
    if (selectedCategory !== 'all' && destination.category !== selectedCategory) {
      return false;
    }
    
    if (selectedDuration !== 'all') {
      if (selectedDuration === '1' && !destination.duration.includes('1 día')) {
        return false;
      }
      if (selectedDuration === '2-3' && !destination.duration.match(/[2-3] día/)) {
        return false;
      }
      if (selectedDuration === '4+' && !destination.duration.match(/[4-9]|[1-9][0-9]+ día/)) {
        return false;
      }
    }
    
    return true;
  });

  const featuredTours = destinations.slice(0, 3);

  return (
    <section className="py-16 bg-white" id="tours">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Nuestros Tours Especializados
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Descubre el Perú con nuestros tours cuidadosamente diseñados. 
            Cada experiencia está pensada para ofrecerte lo mejor de nuestra cultura, historia y naturaleza.
          </p>
        </div>

        {/* Featured Tours */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">Tours Destacados</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredTours.map((tour) => (
              <div
                key={tour.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 group cursor-pointer"
                onClick={() => onTourSelect(tour)}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={tour.images[0]}
                    alt={tour.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h4 className="text-lg font-bold">{tour.name}</h4>
                    <p className="text-sm opacity-90">{tour.region}</p>
                  </div>
                  <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    S/ {tour.price.toLocaleString()}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Clock size={16} />
                        <span>{tour.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star size={16} className="text-yellow-400 fill-current" />
                        <span>{tour.rating}</span>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      tour.difficulty === 'Fácil' ? 'bg-green-100 text-green-600' :
                      tour.difficulty === 'Moderado' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-red-100 text-red-600'
                    }`}>
                      {tour.difficulty}
                    </span>
                  </div>
                  <p className="text-gray-700 text-sm mb-4 line-clamp-2">
                    {tour.shortDescription}
                  </p>
                  <button className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2">
                    <span>Ver Tour Completo</span>
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Explora Todos Nuestros Tours</h3>
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-center">
            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Categoría</label>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center space-x-2 ${
                      selectedCategory === category.id
                        ? 'bg-red-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <span>{category.icon}</span>
                    <span>{category.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Duración</label>
              <select
                value={selectedDuration}
                onChange={(e) => setSelectedDuration(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                {durations.map((duration) => (
                  <option key={duration.id} value={duration.id}>
                    {duration.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Tours Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTours.map((tour) => (
            <div
              key={tour.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 group cursor-pointer"
              onClick={() => onTourSelect(tour)}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={tour.images[0]}
                  alt={tour.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                  <span className="text-sm font-semibold text-gray-800">
                    S/ {tour.price.toLocaleString()}
                  </span>
                </div>
                <div className="absolute top-3 left-3 bg-red-600 text-white rounded-full px-3 py-1">
                  <span className="text-xs font-medium">{tour.category}</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h4 className="text-lg font-bold text-gray-800 group-hover:text-red-600 transition-colors">
                    {tour.name}
                  </h4>
                  <div className="flex items-center space-x-1">
                    <Star size={14} className="text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-600">{tour.rating}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {tour.shortDescription}
                </p>
                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-1">
                    <MapPin size={14} />
                    <span>{tour.region}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock size={14} />
                    <span>{tour.duration}</span>
                  </div>
                </div>
                <button className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium transition-colors">
                  Ver Detalles del Tour
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-gradient-to-r from-red-600 to-red-700 rounded-2xl p-8 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">¿No encuentras el tour perfecto?</h3>
          <p className="text-xl mb-6 opacity-90">
            Diseñamos tours personalizados según tus intereses y preferencias
          </p>
          <button className="bg-white text-red-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-semibold transition-colors">
            Crear Tour Personalizado
          </button>
        </div>
      </div>
    </section>
  );
};

export default ToursSection;
