import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, User, MessageSquare, CheckCircle } from 'lucide-react';
import { useNotification } from '../../contexts/NotificationContext';

const ContactSection: React.FC = () => {
  const { showSuccess, showError } = useNotification();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    tourInterest: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      showSuccess(
        '¡Mensaje enviado!',
        'Gracias por contactarnos. Te responderemos dentro de 24 horas.'
      );
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: '',
        tourInterest: ''
      });
    } catch (error) {
      showError(
        'Error al enviar',
        'Hubo un problema al enviar tu mensaje. Por favor, intenta nuevamente.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: <MapPin size={24} className="text-red-500" />,
      title: 'Dirección',
      details: ['Av. El Sol 123, Cusco', 'Perú, 08000'],
      action: 'Ver en Google Maps'
    },
    {
      icon: <Phone size={24} className="text-red-500" />,
      title: 'Teléfonos',
      details: ['+51 984 567 890', '+51 84 231 456'],
      action: 'Llamar ahora'
    },
    {
      icon: <Mail size={24} className="text-red-500" />,
      title: 'Email',
      details: ['info@perutours.com', 'reservas@perutours.com'],
      action: 'Enviar email'
    },
    {
      icon: <Clock size={24} className="text-red-500" />,
      title: 'Horarios',
      details: ['Lun - Vie: 8:00 AM - 6:00 PM', 'Sáb: 9:00 AM - 2:00 PM'],
      action: 'Horario de atención'
    }
  ];

  const faqs = [
    {
      question: '¿Qué incluyen los tours?',
      answer: 'Nuestros tours incluyen transporte, guía especializado, entradas a sitios turísticos y en muchos casos alimentación. Los detalles específicos se encuentran en cada tour.'
    },
    {
      question: '¿Puedo cancelar mi reserva?',
      answer: 'Sí, puedes cancelar hasta 48 horas antes del tour para un reembolso completo. Para cancelaciones con menos de 48 horas, se aplican políticas específicas.'
    },
    {
      question: '¿Ofrecen tours privados?',
      answer: 'Absolutamente. Ofrecemos tours privados y personalizados para grupos familiares o corporativos. Contáctanos para más detalles.'
    },
    {
      question: '¿Qué debo llevar en los tours?',
      answer: 'Recomendamos ropa cómoda, calzado para caminar, bloqueador solar, sombrero y cámara. Para tours específicos te enviaremos una lista detallada.'
    }
  ];

  return (
    <section className="py-16 bg-gray-50" id="contacto">
      <div className="container mx-auto px-4">
        {/* CABECERA*/}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Contáctanos
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            ¿Tienes preguntas o necesitas ayuda para planificar tu viaje? 
            Nuestro equipo de expertos está aquí para ayudarte a crear la experiencia perfecta.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* FORMULARIO DE CONTACTO */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Envíanos un mensaje</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre completo *
                  </label>
                  <div className="relative">
                    <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="Tu nombre"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <div className="relative">
                    <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Teléfono
                  </label>
                  <div className="relative">
                    <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="+51 123 456 789"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tour de interés
                  </label>
                  <select
                    name="tourInterest"
                    value={formData.tourInterest}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    <option value="">Selecciona un tour</option>
                    <option value="machu-picchu">Machu Picchu</option>
                    <option value="camino-inca">Camino Inca</option>
                    <option value="lago-titicaca">Lago Titicaca</option>
                    <option value="canon-colca">Cañón del Colca</option>
                    <option value="lineas-nazca">Líneas de Nazca</option>
                    <option value="amazonia">Amazonía</option>
                    <option value="personalizado">Tour personalizado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Asunto *
                </label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="¿En qué podemos ayudarte?"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mensaje *
                </label>
                <div className="relative">
                  <MessageSquare size={18} className="absolute left-3 top-3 text-gray-400" />
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={4}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                    placeholder="Cuéntanos sobre tu viaje ideal, fechas de interés, número de viajeros, etc."
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              >
                {isSubmitting ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                ) : (
                  <>
                    <Send size={20} />
                    <span>Enviar Mensaje</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* INFORMACION DEL CONTACTO */}
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Información de contacto</h3>
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">{info.icon}</div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-1">{info.title}</h4>
                      {info.details.map((detail, detailIndex) => (
                        <p key={detailIndex} className="text-gray-600">{detail}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* CONTACTO DE EMERGENCIA */}
            <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
              <h4 className="text-lg font-semibold text-red-800 mb-2">Contacto de Emergencia</h4>
              <p className="text-red-700 mb-2">
                Para emergencias durante tu viaje:
              </p>
              <p className="text-xl font-bold text-red-800">+51 984 567 890</p>
              <p className="text-sm text-red-600 mt-2">Disponible 24/7 durante tu tour</p>
            </div>
          </div>
        </div>

        {/* PREGUNTAS MAS FRECUENTES */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">Preguntas Frecuentes</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {faqs.map((faq, index) => (
              <div key={index} className="space-y-3">
                <h4 className="font-semibold text-gray-800 flex items-start space-x-2">
                  <CheckCircle size={20} className="text-green-500 flex-shrink-0 mt-0.5" />
                  <span>{faq.question}</span>
                </h4>
                <p className="text-gray-600 pl-7">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
