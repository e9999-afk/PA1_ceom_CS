import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Booking } from '../types';

interface BookingState {
  bookings: Booking[];
  currentBooking: Partial<Booking> | null;
  isLoading: boolean;
  error: string | null;
}

type BookingAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_CURRENT_BOOKING'; payload: Partial<Booking> | null }
  | { type: 'ADD_BOOKING'; payload: Booking }
  | { type: 'UPDATE_BOOKING'; payload: { id: string; booking: Partial<Booking> } }
  | { type: 'DELETE_BOOKING'; payload: string }
  | { type: 'SET_BOOKINGS'; payload: Booking[] }
  | { type: 'CLEAR_BOOKINGS' };

const initialState: BookingState = {
  bookings: [],
  currentBooking: null,
  isLoading: false,
  error: null,
};

const STORAGE_KEY = 'perutours_bookings';

const loadBookingsFromStorage = (): Booking[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading bookings from storage:', error);
    return [];
  }
};

const saveBookingsToStorage = (bookings: Booking[]) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
  } catch (error) {
    console.error('Error saving bookings to storage:', error);
  }
};

const bookingReducer = (state: BookingState, action: BookingAction): BookingState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'SET_CURRENT_BOOKING':
      return { ...state, currentBooking: action.payload };
    case 'ADD_BOOKING': {
      const newBookings = [...state.bookings, action.payload];
      saveBookingsToStorage(newBookings);
      return { ...state, bookings: newBookings };
    }
    case 'UPDATE_BOOKING': {
      const updatedBookings = state.bookings.map(booking =>
        booking.id === action.payload.id 
          ? { ...booking, ...action.payload.booking }
          : booking
      );
      saveBookingsToStorage(updatedBookings);
      return { ...state, bookings: updatedBookings };
    }
    case 'DELETE_BOOKING': {
      const filteredBookings = state.bookings.filter(booking => booking.id !== action.payload);
      saveBookingsToStorage(filteredBookings);
      return { ...state, bookings: filteredBookings };
    }
    case 'SET_BOOKINGS':
      return { ...state, bookings: action.payload };
    case 'CLEAR_BOOKINGS':
      saveBookingsToStorage([]);
      return { ...state, bookings: [] };
    default:
      return state;
  }
};

const BookingContext = createContext<{
  state: BookingState;
  dispatch: React.Dispatch<BookingAction>;
  actions: {
    addBooking: (booking: Booking) => void;
    updateBooking: (id: string, booking: Partial<Booking>) => void;
    deleteBooking: (id: string) => void;
    clearBookings: () => void;
    setCurrentBooking: (booking: Partial<Booking> | null) => void;
    setLoading: (loading: boolean) => void;
    setError: (error: string | null) => void;
  };
} | null>(null);

export const BookingProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(bookingReducer, {
    ...initialState,
    bookings: loadBookingsFromStorage(),
  });

  const actions = {
    addBooking: (booking: Booking) => dispatch({ type: 'ADD_BOOKING', payload: booking }),
    updateBooking: (id: string, booking: Partial<Booking>) => 
      dispatch({ type: 'UPDATE_BOOKING', payload: { id, booking } }),
    deleteBooking: (id: string) => dispatch({ type: 'DELETE_BOOKING', payload: id }),
    clearBookings: () => dispatch({ type: 'CLEAR_BOOKINGS' }),
    setCurrentBooking: (booking: Partial<Booking> | null) => 
      dispatch({ type: 'SET_CURRENT_BOOKING', payload: booking }),
    setLoading: (loading: boolean) => dispatch({ type: 'SET_LOADING', payload: loading }),
    setError: (error: string | null) => dispatch({ type: 'SET_ERROR', payload: error }),
  };

  return (
    <BookingContext.Provider value={{ state, dispatch, actions }}>
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};