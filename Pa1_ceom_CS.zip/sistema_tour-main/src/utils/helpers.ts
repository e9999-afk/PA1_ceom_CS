import { Booking } from '../types';

export const formatPrice = (price: number): string => {
  return `S/ ${price.toLocaleString('es-PE')}`;
};

export const formatDate = (date: string): string => {
  return new Date(date).toLocaleDateString('es-PE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

export const calculateTotalPrice = (basePrice: number, travelers: number, additionalServices: number = 0): number => {
  return (basePrice * travelers) + additionalServices;
};

export const getDifficultyColor = (difficulty: string): string => {
  switch (difficulty) {
    case 'Fácil':
      return 'text-green-600 bg-green-100';
    case 'Moderado':
      return 'text-yellow-600 bg-yellow-100';
    case 'Difícil':
      return 'text-red-600 bg-red-100';
    default:
      return 'text-gray-600 bg-gray-100';
  }
};

export const getCategoryIcon = (category: string): string => {
  switch (category) {
    case 'Arqueología':
      return '🏛️';
    case 'Aventura':
      return '🏔️';
    case 'Cultural':
      return '🎭';
    case 'Naturaleza':
      return '🌿';
    case 'Gastronómico':
      return '🍽️';
    default:
      return '🗺️';
  }
};

export const getRegionFlag = (region: string): string => {
  switch (region) {
    case 'Cusco':
      return '🏔️';
    case 'Puno':
      return '🏞️';
    case 'Arequipa':
      return '🌋';
    case 'Ica':
      return '🏜️';
    case 'Loreto':
      return '🌳';
    case 'Lima':
      return '🏙️';
    default:
      return '📍';
  }
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]{7,}$/;
  return phoneRegex.test(phone);
};

export const generateBookingReference = (): string => {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substr(2, 5);
  return `PT-${timestamp}-${random}`.toUpperCase();
};

export const getBookingStatus = (booking: Booking): {
  label: string;
  color: string;
} => {
  switch (booking.status) {
    case 'confirmed':
      return { label: 'Confirmado', color: 'text-green-600 bg-green-100' };
    case 'pending':
      return { label: 'Pendiente', color: 'text-yellow-600 bg-yellow-100' };
    case 'cancelled':
      return { label: 'Cancelado', color: 'text-red-600 bg-red-100' };
    default:
      return { label: 'Desconocido', color: 'text-gray-600 bg-gray-100' };
  }
};

export const getPaymentMethodLabel = (method: string): string => {
  switch (method) {
    case 'yape':
      return 'Yape';
    case 'plin':
      return 'Plin';
    case 'card':
      return 'Tarjeta de Crédito';
    default:
      return 'Método desconocido';
  }
};

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: number | null = null;
  
  return (...args: Parameters<T>) => {
    const later = () => {
      timeout = null;
      func(...args);
    };
    
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = window.setTimeout(later, wait);
  };
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength).trim() + '...';
};

export const isDateInFuture = (date: string): boolean => {
  const selectedDate = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return selectedDate > today;
};

export const getDistanceText = (region: string): string => {
  const distances: { [key: string]: string } = {
    'Cusco': '1,165 km desde Lima',
    'Puno': '1,310 km desde Lima',
    'Arequipa': '1,010 km desde Lima',
    'Ica': '300 km desde Lima',
    'Loreto': '1,150 km desde Lima',
    'Lima': 'En Lima'
  };
  
  return distances[region] || 'Distancia no disponible';
};
