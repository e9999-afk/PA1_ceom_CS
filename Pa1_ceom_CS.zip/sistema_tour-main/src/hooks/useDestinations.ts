import { useState, useMemo, useCallback } from 'react';
import { SearchFilters } from '../types';
import { destinations } from '../data/destinations';

const initialFilters: SearchFilters = {
  region: '',
  category: '',
  priceRange: [0, 1000],
  difficulty: '',
  duration: '',
};

export const useDestinations = () => {
  const [filters, setFilters] = useState<SearchFilters>(initialFilters);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'price' | 'rating' | 'name' | 'duration'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const filteredDestinations = useMemo(() => {
    let filtered = destinations.filter(destination => {
      if (searchTerm && 
          !destination.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !destination.description.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !destination.region.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !destination.category.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !destination.highlights.some(h => h.toLowerCase().includes(searchTerm.toLowerCase()))) {
        return false;
      }

      if (filters.region && destination.region !== filters.region) {
        return false;
      }

      if (filters.category && destination.category !== filters.category) {
        return false;
      }

      if (destination.price < filters.priceRange[0] || destination.price > filters.priceRange[1]) {
        return false;
      }

      if (filters.difficulty && destination.difficulty !== filters.difficulty) {
        return false;
      }

      if (filters.duration) {
        if (filters.duration === '1 día' && !destination.duration.includes('1 día')) {
          return false;
        }
        if (filters.duration === '2-3 días' && !destination.duration.match(/[2-3] día/)) {
          return false;
        }
        if (filters.duration === '4+ días' && !destination.duration.match(/[4-9]|[1-9][0-9]+ día/)) {
          return false;
        }
      }

      return true;
    });

    filtered.sort((a, b) => {
      let aValue: string | number;
      let bValue: string | number;

      switch (sortBy) {
        case 'price':
          aValue = a.price;
          bValue = b.price;
          break;
        case 'rating':
          aValue = a.rating;
          bValue = b.rating;
          break;
        case 'name':
          aValue = a.name;
          bValue = b.name;
          break;
        case 'duration':
          aValue = parseInt(a.duration);
          bValue = parseInt(b.duration);
          break;
        default:
          aValue = a.name;
          bValue = b.name;
      }

      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortOrder === 'asc' 
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return sortOrder === 'asc' 
        ? (aValue as number) - (bValue as number)
        : (bValue as number) - (aValue as number);
    });

    return filtered;
  }, [filters, searchTerm, sortBy, sortOrder]);

  const getAvailableRegions = useCallback(() => {
    return Array.from(new Set(destinations.map(d => d.region))).sort();
  }, []);

  const getAvailableCategories = useCallback(() => {
    return Array.from(new Set(destinations.map(d => d.category))).sort();
  }, []);

  const clearFilters = useCallback(() => {
    setFilters(initialFilters);
    setSearchTerm('');
  }, []);

  const updateFilter = useCallback((key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  return {
    destinations: filteredDestinations,
    filters,
    setFilters,
    updateFilter,
    searchTerm,
    setSearchTerm,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
    clearFilters,
    getAvailableRegions,
    getAvailableCategories,
    totalCount: destinations.length,
    filteredCount: filteredDestinations.length,
  };
};