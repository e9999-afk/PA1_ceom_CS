export interface Destination {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  region: string;
  price: number;
  duration: string;
  difficulty: 'Fácil' | 'Moderado' | 'Difícil';
  category: string;
  images: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
  highlights: string[];
  included: string[];
  notIncluded: string[];
  itinerary: ItineraryDay[];
  rating: number;
  reviewCount: number;
}

export interface ItineraryDay {
  day: number;
  title: string;
  activities: string[];
  meals: string[];
  accommodation?: string;
}

export interface Booking {
  id: string;
  destinationId: string;
  destination: Destination;
  userInfo: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    document: string;
  };
  travelDate: string;
  travelers: number;
  totalPrice: number;
  paymentMethod: 'yape' | 'plin' | 'card';
  paymentStatus: 'pending' | 'completed' | 'failed';
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
}

export interface SearchFilters {
  region: string;
  category: string;
  priceRange: [number, number];
  difficulty: string;
  duration: string;
}