import { Destination } from '../types';

export const destinations: Destination[] = [
  {
    id: '1',
    name: 'Machu Picchu',
    description: 'Descubre la ciudadela inca más famosa del mundo, declarada Patrimonio de la Humanidad por la UNESCO. Machu Picchu te sorprenderá con su arquitectura única, su historia milenaria y sus paisajes espectaculares entre las montañas de los Andes.',
    shortDescription: 'La ciudadela inca más famosa del mundo',
    region: 'Cusco',
    price: 450,
    duration: '2 días / 1 noche',
    difficulty: 'Moderado',
    category: 'Arqueología',
    images: [
      'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg',
      'https://www.ollantaytambo.org/img/inca-trail-4-days-to-machu-picchu-018-01.jpg',
      'https://turismo.encolombia.com/wp-content/uploads/2012/12/lago-Titicaca.jpg'
    ],
    coordinates: { lat: -13.1631, lng: -72.5450 },
    highlights: [
      'Tren panorámico a Aguas Calientes',
      'Guía especializado en historia inca',
      'Amanecer en Machu Picchu',
      'Vista del Huayna Picchu'
    ],
    included: [
      'Transporte en tren',
      'Guía turístico profesional',
      'Entradas a Machu Picchu',
      'Alojamiento en Aguas Calientes',
      'Desayuno buffet'
    ],
    notIncluded: [
      'Vuelos a Cusco',
      'Almuerzo y cena',
      'Entrada a Huayna Picchu',
      'Propinas'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Viaje a Aguas Calientes',
        activities: [
          'Recojo del hotel en Cusco',
          'Viaje en tren panorámico',
          'Llegada a Aguas Calientes',
          'Check-in en hotel'
        ],
        meals: ['Desayuno'],
        accommodation: 'Hotel en Aguas Calientes'
      },
      {
        day: 2,
        title: 'Machu Picchu',
        activities: [
          'Madrugada temprana',
          'Bus a Machu Picchu',
          'Tour guiado de 3 horas',
          'Retorno a Cusco'
        ],
        meals: ['Desayuno']
      }
    ],
    rating: 4.9,
    reviewCount: 1247
  },
  {
    id: '2',
    name: 'Camino Inca',
    description: 'Vive la experiencia más auténtica para llegar a Machu Picchu siguiendo los pasos de los antiguos incas. Este trekking de 4 días te llevará por paisajes andinos espectaculares, sitios arqueológicos únicos y la experiencia de acampar bajo las estrellas.',
    shortDescription: 'Trekking de 4 días hacia Machu Picchu',
    region: 'Cusco',
    price: 680,
    duration: '4 días / 3 noches',
    difficulty: 'Difícil',
    category: 'Aventura',
    images: [
      'https://www.ollantaytambo.org/img/inca-trail-4-days-to-machu-picchu-018-01.jpg',
      'https://www.ollantaytambo.org/img/inca-trail-4-days-to-machu-picchu-018-01.jpg'
    ],
    coordinates: { lat: -13.2543, lng: -72.1421 },
    highlights: [
      'Camino original inca',
      'Campamento bajo estrellas',
      'Sitios arqueológicos únicos',
      'Puerta del Sol al amanecer'
    ],
    included: [
      'Guía especializado',
      'Porteadores',
      'Equipo de campamento',
      'Todas las comidas',
      'Entradas a sitios'
    ],
    notIncluded: [
      'Bolsa de dormir',
      'Bastones de trekking',
      'Seguro de viaje',
      'Propinas para porteadores'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Wayllabamba',
        activities: ['Inicio del trekking', 'Caminata a Wayllabamba'],
        meals: ['Almuerzo', 'Cena'],
        accommodation: 'Campamento'
      },
      {
        day: 2,
        title: 'Paso de Warmiwañusca',
        activities: ['Cruce del paso más alto', 'Descenso a Pacaymayo'],
        meals: ['Desayuno', 'Almuerzo', 'Cena'],
        accommodation: 'Campamento'
      },
      {
        day: 3,
        title: 'Wiñay Wayna',
        activities: ['Sitios arqueológicos', 'Campamento final'],
        meals: ['Desayuno', 'Almuerzo', 'Cena'],
        accommodation: 'Campamento'
      },
      {
        day: 4,
        title: 'Machu Picchu',
        activities: ['Puerta del Sol', 'Tour completo', 'Retorno'],
        meals: ['Desayuno']
      }
    ],
    rating: 4.8,
    reviewCount: 892
  },
  {
    id: '3',
    name: 'Lago Titicaca',
    description: 'Explora el lago navegable más alto del mundo y conoce las fascinantes culturas que viven en sus islas flotantes. Descubre las tradiciones ancestrales de los uros y la belleza natural del altiplano peruano.',
    shortDescription: 'El lago navegable más alto del mundo',
    region: 'Puno',
    price: 280,
    duration: '2 días / 1 noche',
    difficulty: 'Fácil',
    category: 'Cultural',
    images: [
      'https://turismo.encolombia.com/wp-content/uploads/2012/12/lago-Titicaca.jpg',
      'https://turismo.encolombia.com/wp-content/uploads/2012/12/lago-Titicaca.jpg'
    ],
    coordinates: { lat: -15.8422, lng: -69.7272 },
    highlights: [
      'Islas flotantes de los Uros',
      'Isla Taquile y sus textiles',
      'Navegación en totora',
      'Cultura viva del altiplano'
    ],
    included: [
      'Transporte acuático',
      'Guía local',
      'Alojamiento familiar',
      'Experiencia textil',
      'Comida típica'
    ],
    notIncluded: [
      'Transporte a Puno',
      'Bebidas alcohólicas',
      'Compras personales',
      'Seguro de viaje'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Islas Flotantes',
        activities: ['Navegación matutina', 'Visita a los Uros', 'Isla Taquile'],
        meals: ['Almuerzo'],
        accommodation: 'Casa familiar'
      },
      {
        day: 2,
        title: 'Experiencia Cultural',
        activities: ['Taller de textiles', 'Navegación de retorno'],
        meals: ['Desayuno', 'Almuerzo']
      }
    ],
    rating: 4.6,
    reviewCount: 634
  },
  {
    id: '4',
    name: 'Cañón del Colca',
    description: 'Admira el vuelo majestuoso de los cóndores en uno de los cañones más profundos del mundo. El Cañón del Colca ofrece paisajes espectaculares, aguas termales naturales y pueblos tradicionales que conservan sus costumbres ancestrales.',
    shortDescription: 'Uno de los cañones más profundos del mundo',
    region: 'Arequipa',
    price: 320,
    duration: '2 días / 1 noche',
    difficulty: 'Moderado',
    category: 'Naturaleza',
    images: [
      'https://www.peru.travel/Contenido/Atractivo/Imagen/es/8/1.2/Principal/Ca%C3%B1on%20del%20Colca.jpg',
      'https://www.peru.travel/Contenido/Atractivo/Imagen/es/8/1.2/Principal/Ca%C3%B1on%20del%20Colca.jpg'
    ],
    coordinates: { lat: -15.6217, lng: -71.9981 },
    highlights: [
      'Cruz del Cóndor',
      'Vuelo de cóndores',
      'Aguas termales La Calera',
      'Pueblos tradicionales'
    ],
    included: [
      'Transporte turístico',
      'Alojamiento en Chivay',
      'Entrada al Cañón',
      'Guía especializado',
      'Desayuno'
    ],
    notIncluded: [
      'Almuerzo y cena',
      'Entrada a aguas termales',
      'Bebidas',
      'Compras personales'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Chivay y Aguas Termales',
        activities: ['Viaje por la Reserva Nacional', 'Llegada a Chivay', 'Aguas termales'],
        meals: ['Almuerzo'],
        accommodation: 'Hotel en Chivay'
      },
      {
        day: 2,
        title: 'Cruz del Cóndor',
        activities: ['Mirador Cruz del Cóndor', 'Observación de cóndores', 'Retorno'],
        meals: ['Desayuno']
      }
    ],
    rating: 4.7,
    reviewCount: 523
  },
  {
    id: '5',
    name: 'Líneas de Nazca',
    description: 'Sobrevuela uno de los misterios más grandes de la humanidad. Las Líneas de Nazca, con sus enormes geoglifos que solo pueden apreciarse desde el aire, te ofrecerán una experiencia única e inolvidable en el desierto peruano.',
    shortDescription: 'Misteriosos geoglifos desde las alturas',
    region: 'Ica',
    price: 380,
    duration: '1 día',
    difficulty: 'Fácil',
    category: 'Arqueología',
    images: [
      'https://files.pucp.education/puntoedu/wp-content/uploads/2025/06/04172152/web-1920x1080-lineas-de-nazca.jpg',
      'https://files.pucp.education/puntoedu/wp-content/uploads/2025/06/04172152/web-1920x1080-lineas-de-nazca.jpg'
    ],
    coordinates: { lat: -14.8394, lng: -75.1319 },
    highlights: [
      'Sobrevuelo en avioneta',
      'Figuras del mono y colibrí',
      'Mirador natural',
      'Centro de interpretación'
    ],
    included: [
      'Sobrevuelo de 30 minutos',
      'Certificado de vuelo',
      'Transporte al aeropuerto',
      'Guía especializado',
      'Seguro de vuelo'
    ],
    notIncluded: [
      'Impuesto aeroportuario',
      'Almuerzo',
      'Bebidas',
      'Compras personales'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Líneas de Nazca',
        activities: [
          'Recojo del hotel',
          'Traslado al aeropuerto',
          'Sobrevuelo de las líneas',
          'Visita al mirador',
          'Retorno'
        ],
        meals: ['Desayuno']
      }
    ],
    rating: 4.5,
    reviewCount: 1089
  },
  {
    id: '6',
    name: 'Amazonía - Iquitos',
    description: 'Sumérgete en la selva amazónica peruana y descubre la biodiversidad más rica del planeta. Navega por el río Amazonas, conoce comunidades nativas y observa especies únicas en su hábitat natural.',
    shortDescription: 'Aventura en la selva amazónica',
    region: 'Loreto',
    price: 520,
    duration: '3 días / 2 noches',
    difficulty: 'Moderado',
    category: 'Naturaleza',
    images: [
      'https://turismo.encolombia.com/wp-content/uploads/2012/12/Turismo-en-Iquitos.webp',
      'https://turismo.encolombia.com/wp-content/uploads/2012/12/Turismo-en-Iquitos.webp'
    ],
    coordinates: { lat: -3.7437, lng: -73.2516 },
    highlights: [
      'Navegación por el Amazonas',
      'Avistamiento de delfines rosados',
      'Comunidades nativas',
      'Caminatas nocturnas'
    ],
    included: [
      'Alojamiento en lodge',
      'Todas las comidas',
      'Transporte fluvial',
      'Guía naturalista',
      'Actividades programadas'
    ],
    notIncluded: [
      'Vuelos a Iquitos',
      'Bebidas alcohólicas',
      'Actividades opcionales',
      'Propinas'
    ],
    itinerary: [
      {
        day: 1,
        title: 'Llegada al Amazonas',
        activities: ['Recepción en Iquitos', 'Navegación al lodge', 'Caminata introductoria'],
        meals: ['Almuerzo', 'Cena'],
        accommodation: 'Lodge amazónico'
      },
      {
        day: 2,
        title: 'Exploración Profunda',
        activities: ['Observación de aves', 'Visita a comunidad nativa', 'Pesca de pirañas'],
        meals: ['Desayuno', 'Almuerzo', 'Cena'],
        accommodation: 'Lodge amazónico'
      },
      {
        day: 3,
        title: 'Último Día',
        activities: ['Caminata matutina', 'Avistamiento de delfines', 'Retorno a Iquitos'],
        meals: ['Desayuno', 'Almuerzo']
      }
    ],
    rating: 4.8,
    reviewCount: 456
  }
];